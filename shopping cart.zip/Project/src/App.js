
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { NavLink } from 'react-router-dom';
import './App.css';
import { Navbar } from './components/Navbar';
import { Login } from './components/Login';
import { Registration } from './components/Registration';
import { About } from './components/About';
import { Contact } from './components/Contact';

function App() {
  let today=new Date();
  let date = today.getDate()+"-"+(today.getMonth()+1)+"-"+(today.getFullYear());
  return (
    <div className="App">
      <Router>
        <Navbar/>
        <Routes>
          <Route path="/login" element={<Login/>}/>
          <Route path="/about" element={<About/>}/>
          <Route path="/contact" element={<Contact/>}/>
          <Route path="/register" element={<Registration/>}/>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
