import React from "react";

export const Contact=()=>{
    return(
        <div className="contact">
            <h1>This is Contact page</h1>
        </div>
    )
}