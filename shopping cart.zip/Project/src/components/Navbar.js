import React from "react";
import { Link } from "react-router-dom";
import './navbar.css'; 


export const Navbar=()=>{
    return (
        <div className="navbar">
            <h1>Student Management</h1>
            <ul>
                <li><Link to="/login">Login</Link></li>
                <li><Link to="/register">Register</Link></li>
                <li><Link to="/contact">Contact us</Link></li>
                <li><Link to="/about">About us</Link></li>
            </ul>

            
        </div>
    )
}