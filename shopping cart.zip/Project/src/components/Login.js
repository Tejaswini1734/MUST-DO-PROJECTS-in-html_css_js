import React from "react";

export const Login=()=>{
    return (
        <div className="login">
            <h1>This is login page</h1>
        </div>
    )
}