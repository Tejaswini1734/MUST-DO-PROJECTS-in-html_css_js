import React from "react";

export const Registration=()=>{
    return (
        <div className="register">
            <h1>This is Registration page</h1>
        </div>
    )
}